import React, { useEffect, useState } from "react";

export default function Home() {
  const [email, setEmail] = useState();
  const [password, setPassword] = useState();
  const [data, setData] = useState([]);

  useEffect(() => {
    fetch("http://localhost:3001/categories")
      .then((res) => res.json())
      .then((response) => setData(response));
  }, []);

  return (
    <>
      <h1>Bookshelf</h1>
      <div className="container">
        <div className="main">
          <form>
            <input
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            ></input>
            <div>
              <input
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              ></input>
            </div>
            <div>
              <button>Login</button>
            </div>
          </form>
        </div>
        <div className="search">
          <div>
            <input placeholder="Title"></input>
            <i class="fa fa-search" aria-hidden="true"></i>
          </div>

          {data.map((x) => (
            <button className="data">{x.name}</button>
          ))}
        </div>
      </div>
    </>
  );
}
